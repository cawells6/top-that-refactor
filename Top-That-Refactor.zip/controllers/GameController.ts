import { Server, Socket } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';

import GameState, { Card, CardValue } from '../models/GameState.js';
import Player from '../models/Player.js';
import {
  JOIN_GAME,
  JOINED,
  PLAYER_JOINED,
  LOBBY,
  STATE_UPDATE,
  SPECIAL_CARD_EFFECT,
  REJOIN,
  START_GAME,
  NEXT_TURN,
  GAME_OVER,
  CARD_PLAYED,
  PILE_PICKED_UP,
  ERROR as ERROR_EVENT,
  PLAY_CARD,
  PICK_UP_PILE,
} from '../src/shared/events.js';
import {
  normalizeCardValue,
  isSpecialCard,
  isTwoCard,
  isFiveCard,
  isTenCard,
} from '../utils/cardUtils.js';

interface PlayerJoinData {
  id?: string;
  name?: string;
  numHumans?: number;
  numCPUs?: number;
}

interface StartGameOptions {
  computerCount?: number;
  socket?: Socket;
}

interface PlayData {
  cardIndices: number[];
  zone: 'hand' | 'upCards' | 'downCards';
}

interface RejoinData {
  roomId: string;
  playerId: string;
}

interface ClientStatePlayer {
  id: string;
  name: string;
  handCount?: number;
  upCount?: number;
  downCount?: number;
  hand?: Card[];
  upCards?: Card[];
  downCards?: Card[];
  disconnected: boolean;
  error?: string;
}

interface ClientState {
  players: ClientStatePlayer[];
  pile: Card[];
  discardCount: number;
  deckCount: number;
  currentPlayerId: string | undefined;
  started: boolean;
  lastRealCard: Card | null;
}

export class GameRoomManager {
  private io: Server;
  private rooms: Map<string, GameController>;

  constructor(io: Server) {
    this.io = io;
    this.rooms = new Map();
    this.io.on('connection', (socket: Socket) => {
      this.log(`New connection: ${socket.id}`);
      socket.on(
        JOIN_GAME,
        (
          playerData: PlayerJoinData,
          ack?: (response: { roomId: string; playerId: string } | { error: string }) => void
        ) => {
          this.handleClientJoinGame(socket, playerData, ack);
        }
      );

      socket.on(
        REJOIN,
        (
          rejoinData: RejoinData,
          ack?: (response: { success: boolean; error?: string }) => void
        ) => {
          const controller = this.rooms.get(rejoinData.roomId);
          if (controller) {
            controller.publicHandleRejoin(socket, rejoinData.roomId, rejoinData.playerId, ack);
          } else {
            this.log(`Rejoin attempt for non-existent room: ${rejoinData.roomId}`);
            if (ack) ack({ success: false, error: 'Room not found' });
            socket.emit(ERROR_EVENT, 'Room not found for rejoin.');
          }
        }
      );
    });

    setInterval(() => {
      for (const [roomId, controller] of this.rooms.entries()) {
        const hasActivePlayers = Array.from(controller['players'].values()).some(
          (p) => !p.disconnected
        );
        if (!hasActivePlayers && !controller['gameState'].started) {
          this.rooms.delete(roomId);
        }
      }
    }, 60000);
  }

  private log(message: string, ...args: any[]): void {
    console.log(`[GameRoomManager] ${message}`, ...args);
  }

  private handleClientJoinGame(
    socket: Socket,
    playerData: PlayerJoinData,
    ack?: (response: { roomId: string; playerId: string } | { error: string }) => void
  ): void {
    let roomId = playerData.id;
    let controller: GameController | undefined;

    if (roomId) {
      controller = this.rooms.get(roomId);
    }

    if (!controller) {
      roomId = uuidv4().slice(0, 6);
      this.log(`Creating new room ${roomId} for player ${playerData.name || socket.id}`);
      controller = new GameController(this.io, roomId);
      this.rooms.set(roomId, controller);
    } else {
      this.log(`Player ${playerData.name || socket.id} attempting to join existing room ${roomId}`);
    }

    controller.publicHandleJoin(socket, playerData, ack);
  }
}

export default class GameController {
  private io: Server;
  private gameState: GameState;
  private players: Map<string, Player>;
  private socketIdToPlayerId: Map<string, string>;
  private roomId: string;

  private log(message: string, ...args: any[]): void {
    console.log(`[GameController ${this.roomId}] ${message}`, ...args);
  }

  constructor(io: Server, roomId: string) {
    this.io = io;
    this.roomId = roomId;
    this.gameState = new GameState();
    this.players = new Map<string, Player>();
    this.socketIdToPlayerId = new Map<string, string>();
    this.log('GameController instance created.');
  }

  public attachSocketEventHandlers(socket: Socket): void {
    this.log(`Attaching event handlers for socket ${socket.id}`);
    socket.removeAllListeners(START_GAME);
    socket.removeAllListeners(PLAY_CARD);
    socket.removeAllListeners(PICK_UP_PILE);
    socket.removeAllListeners(REJOIN);
    socket.removeAllListeners('disconnect');

    socket.on(START_GAME, (opts: Pick<StartGameOptions, 'computerCount'> = {}) =>
      this.handleStartGame({ ...opts, socket })
    );
    socket.on(PLAY_CARD, (data: PlayData) => this.handlePlayCard(socket, data));
    socket.on(PICK_UP_PILE, () => this.handlePickUpPile(socket));
    socket.on('disconnect', () => this.handleDisconnect(socket));
  }

  private getLobbyPlayerList(): { id: string; name: string; disconnected: boolean }[] {
    return Array.from(this.players.values()).map((p: Player) => ({
      id: p.id,
      name: p.name,
      disconnected: p.disconnected,
    }));
  }

  public publicHandleJoin(
    socket: Socket,
    playerData: PlayerJoinData,
    ack?: (response: { roomId: string; playerId: string } | { error: string }) => void
  ): void {
    this.attachSocketEventHandlers(socket);
    this.handleJoin(socket, playerData, ack);
  }

  public publicHandleRejoin(
    socket: Socket,
    roomId: string,
    playerId: string,
    ack?: (response: { success: boolean; error?: string }) => void
  ): void {
    this.attachSocketEventHandlers(socket);
    this.handleRejoin(socket, roomId, playerId, ack);
  }

  private handleRejoin(
    socket: Socket,
    roomId: string,
    playerId: string,
    ack?: (response: { success: boolean; error?: string }) => void
  ): void {
    this.log(`Attempting to rejoin player ${playerId} in room ${roomId} with socket ${socket.id}`);
    if (roomId !== this.roomId) {
      this.log(`Rejoin failed: Mismatched room ID. Expected ${this.roomId}, got ${roomId}`);
      if (ack) ack({ success: false, error: 'Invalid room for rejoin.' });
      socket.emit(ERROR_EVENT, 'Invalid room for rejoin.');
      return;
    }
    const player = this.players.get(playerId);
    if (player) {
      this.log(
        `Player ${playerId} found. Updating socket ID from ${player.socketId} to ${socket.id} and joining room.`
      );
      socket.join(this.roomId);
      player.socketId = socket.id;
      player.disconnected = false;
      this.socketIdToPlayerId.set(socket.id, playerId);

      socket.emit(JOINED, { id: player.id, name: player.name, roomId: this.roomId });
      this.log(`Emitted JOINED to rejoining player ${player.name}`);

      this.pushState();
      this.io.to(this.roomId).emit(LOBBY, {
        roomId: this.roomId,
        players: this.getLobbyPlayerList(),
        maxPlayers: this.gameState.maxPlayers,
      });
      this.log(`Pushed state and lobby info to room ${this.roomId} after rejoin.`);
      if (ack) ack({ success: true });
    } else {
      this.log(`Rejoin failed: Player ${playerId} not found in this room.`);
      if (ack) ack({ success: false, error: `Player ${playerId} not found for rejoin.` });
      socket.emit(ERROR_EVENT, `Player ${playerId} not found for rejoin.`);
    }
  }

  private handleJoin(
    socket: Socket,
    playerData: PlayerJoinData,
    ack?: (response: { roomId: string; playerId: string } | { error: string }) => void
  ): void {
    let id = playerData.id || socket.id;
    let name = playerData.name || `Player-${id.substring(0, 4)}`;
    this.log(
      `Handling join request for player: ${name} (Proposed ID: ${id}, Socket: ${socket.id})`
    );

    const existingPlayer = this.players.get(id);
    if (existingPlayer && !existingPlayer.disconnected) {
      this.log(`Player ID '${id}' (${name}) is already active. Emitting ERROR_EVENT.`);
      if (ack) ack({ error: `Player ID '${id}' is already active in a game.` });
      else socket.emit(ERROR_EVENT, `Player ID '${id}' is already active in a game.`);
      return;
    }

    if (existingPlayer && existingPlayer.disconnected) {
      this.log(`Player ID '${id}' (${name}) is disconnected. Attempting rejoin logic.`);
      this.handleRejoin(
        socket,
        this.roomId,
        id,
        ack
          ? (rejoinAck) => {
              if (rejoinAck.success) {
                if (ack) ack({ roomId: this.roomId, playerId: id });
              } else {
                if (ack) ack({ error: rejoinAck.error || 'Rejoin failed' });
              }
            }
          : undefined
      );
      return;
    }

    if (this.gameState.started) {
      this.log(`Game already started. Player '${name}' cannot join. Emitting ERROR_EVENT.`);
      if (ack) ack({ error: 'Game has already started. Cannot join.' });
      else socket.emit(ERROR_EVENT, 'Game has already started. Cannot join.');
      return;
    }

    if (this.players.size >= this.gameState.maxPlayers) {
      this.log(`Game room is full. Player '${name}' cannot join. Emitting ERROR_EVENT.`);
      if (ack) ack({ error: 'Game room is full.' });
      else socket.emit(ERROR_EVENT, 'Game room is full.');
      return;
    }

    this.log(`Adding player '${name}' (ID: ${id}) to game state.`);
    this.gameState.addPlayer(id);
    const player = new Player(id);
    player.name = name;
    player.socketId = socket.id;
    this.players.set(id, player);
    this.socketIdToPlayerId.set(socket.id, id);

    socket.join(this.roomId);
    this.log(
      `Player '${name}' (Socket ID: ${socket.id}) joined room '${this.roomId}'. Emitting JOINED.`
    );
    socket.emit(JOINED, { id: player.id, name: player.name, roomId: this.roomId });
    if (ack) ack({ roomId: this.roomId, playerId: player.id });

    const currentLobbyPlayers = this.getLobbyPlayerList();
    this.log(
      `Emitting PLAYER_JOINED and LOBBY to room '${this.roomId}'. Players:`,
      currentLobbyPlayers
    );
    this.io.to(this.roomId).emit(PLAYER_JOINED, currentLobbyPlayers);
    this.io.to(this.roomId).emit(LOBBY, {
      roomId: this.roomId,
      players: currentLobbyPlayers,
      maxPlayers: this.gameState.maxPlayers,
    });

    const autoStartEnabled = true;
    const desiredNumHumans = playerData.numHumans || 1;
    const desiredNumCPUs = playerData.numCPUs || 0;

    this.log(
      `Checking auto-start conditions: autoStartEnabled=${autoStartEnabled}, players.size=${this.players.size}, desiredNumHumans=${desiredNumHumans}, desiredNumCPUs=${desiredNumCPUs}, gameState.started=${this.gameState.started}`
    );

    if (
      autoStartEnabled &&
      this.players.size === 1 &&
      desiredNumHumans === 1 &&
      1 + desiredNumCPUs >= 2 &&
      !this.gameState.started
    ) {
      this.log(
        `Auto-starting game. Player: ${name} (the only human), CPUs: ${desiredNumCPUs}. Total players: ${
          1 + desiredNumCPUs
        }`
      );
      this.handleStartGame({ computerCount: desiredNumCPUs, socket });
    } else {
      this.log(
        `Not auto-starting. Conditions not met or game configured for multiple humans (desiredNumHumans=${desiredNumHumans}). Transitioning to lobby/waiting state.`
      );
      this.pushState();
    }
  }

  private async handleStartGame(opts: StartGameOptions): Promise<void> {
    const computerCount = opts.computerCount || 0;
    const requestingSocket = opts.socket;
    this.log(
      `Handling start game request. Computer count: ${computerCount}. Requested by: ${requestingSocket?.id}`
    );

    if (this.gameState.started) {
      const errorMsg = 'Game has already started.';
      this.log(`Start game failed: ${errorMsg}`);
      if (requestingSocket) requestingSocket.emit(ERROR_EVENT, errorMsg);
      return;
    }

    this.players.forEach((player) => {
      if (!this.gameState.players.includes(player.id)) {
        this.gameState.addPlayer(player.id);
        this.log(`Added player ${player.id} to gameState.players before starting.`);
      }
    });

    const currentHumanPlayers = Array.from(this.players.values()).filter(
      (p: Player) => !p.isComputer
    ).length;

    this.log(
      `Current human players: ${currentHumanPlayers}. Desired CPUs: ${computerCount}. Total players before adding CPUs: ${this.players.size}`
    );

    if (currentHumanPlayers === 0 && computerCount < 2) {
      const errorMsg = 'At least two players (humans or CPUs) are required to start.';
      this.log(`Start game failed: ${errorMsg}`);
      if (requestingSocket) requestingSocket.emit(ERROR_EVENT, errorMsg);
      return;
    }
    if (currentHumanPlayers > 0 && currentHumanPlayers + computerCount < 2) {
      const errorMsg = 'At least two total players (humans + CPUs) are required.';
      this.log(`Start game failed: ${errorMsg}`);
      if (requestingSocket) requestingSocket.emit(ERROR_EVENT, errorMsg);
      return;
    }
    if (currentHumanPlayers + computerCount > this.gameState.maxPlayers) {
      const errorMsg = `Cannot start: Total players (${currentHumanPlayers + computerCount}) would exceed max players (${this.gameState.maxPlayers}).`;
      this.log(`Start game failed: ${errorMsg}`);
      if (requestingSocket) requestingSocket.emit(ERROR_EVENT, errorMsg);
      return;
    }

    for (let i = 0; i < computerCount; i++) {
      if (this.players.size >= this.gameState.maxPlayers) {
        this.log('Max players reached, cannot add more CPUs.');
        break;
      }
      const cpuId = `COMPUTER_${i + 1}`;
      if (!this.players.has(cpuId)) {
        const cpuPlayer = new Player(cpuId);
        cpuPlayer.name = `CPU ${i + 1}`;
        cpuPlayer.isComputer = true;
        this.players.set(cpuId, cpuPlayer);
        if (!this.gameState.players.includes(cpuId)) {
          this.gameState.addPlayer(cpuId);
        }
        this.log(`Added CPU player ${cpuId}. Total players now: ${this.players.size}`);
      }
    }
    this.log(
      `Finished adding CPUs. Total players in this.players: ${this.players.size}. Players in gameState: ${this.gameState.players.length}`
    );

    this.players.forEach((p) => {
      if (!this.gameState.players.includes(p.id)) {
        this.gameState.addPlayer(p.id);
        this.log(`Final sync: Added player ${p.id} to gameState.players.`);
      }
    });

    this.gameState.startGameInstance();
    this.log(
      `Game instance started. Players in gameState after start: ${this.gameState.players.join(', ')}`
    );

    const numPlayers = this.gameState.players.length;
    if (numPlayers < 2) {
      const errorMsg = `Not enough players to start (need at least 2, have ${numPlayers}).`;
      this.log(
        `Start game failed: ${errorMsg}. Players in gameState: ${this.gameState.players.join(', ')}`
      );
      this.gameState.started = false;
      if (requestingSocket) requestingSocket.emit(ERROR_EVENT, errorMsg);
      return;
    }

    this.log(`Dealing cards for ${numPlayers} players: ${this.gameState.players.join(', ')}`);
    const { hands, upCards, downCards } = this.gameState.dealCards(numPlayers);

    this.gameState.players.forEach((id: string, idx: number) => {
      const player = this.players.get(id);
      if (!player) {
        return;
      }
      player.setHand(hands[idx] || []);
      player.setUpCards(upCards[idx] || []);
      player.setDownCards(downCards[idx] || []);
    });

    this.gameState.started = true;
    this.gameState.currentPlayerIndex = 0;

    const firstPlayerId = this.gameState.players[this.gameState.currentPlayerIndex];
    this.log(
      `Game started successfully. First player: ${firstPlayerId}. Emitting NEXT_TURN and pushing state.`
    );

    this.pushState();
    this.io.to(this.roomId).emit(NEXT_TURN, firstPlayerId);

    const firstPlayer = this.players.get(firstPlayerId);
    if (firstPlayer && firstPlayer.isComputer) {
      this.log(`First player ${firstPlayerId} is a CPU. Initiating their turn.`);
      setTimeout(() => this.playComputerTurn(firstPlayer), 1200);
    }
  }

  private handlePlayCard(socket: Socket, { cardIndices, zone }: PlayData): void {
    const playerId = this.socketIdToPlayerId.get(socket.id);
    this.log(
      `Handling play card request from socket ${socket.id} (Player ID: ${playerId}). Zone: ${zone}, Indices: ${cardIndices}`
    );
    if (!playerId) {
      socket.emit(ERROR_EVENT, 'Player not recognized.');
      return;
    }

    const player = this.players.get(playerId);
    if (!player) {
      socket.emit(ERROR_EVENT, 'Player data not found.');
      return;
    }

    if (this.gameState.players[this.gameState.currentPlayerIndex] !== playerId) {
      socket.emit(ERROR_EVENT, 'Not your turn.');
      return;
    }

    if (!cardIndices || cardIndices.length === 0) {
      socket.emit(ERROR_EVENT, 'No cards selected to play.');
      return;
    }

    const cardsToPlay: Card[] = [];
    let sourceZone: Card[] | undefined;
    if (zone === 'hand') sourceZone = player.hand;
    else if (zone === 'upCards') sourceZone = player.upCards;
    else if (zone === 'downCards') sourceZone = player.downCards;

    if (!sourceZone) {
      socket.emit(ERROR_EVENT, 'Invalid zone.');
      return;
    }

    for (const index of cardIndices) {
      if (index < 0 || index >= sourceZone.length) {
        socket.emit(ERROR_EVENT, 'Invalid card index.');
        return;
      }
      cardsToPlay.push(sourceZone[index]);
    }

    if (zone === 'downCards' && cardsToPlay.length > 1) {
      socket.emit(ERROR_EVENT, 'Can only play one down card.');
      return;
    }

    this.handlePlayCardInternal(player, cardIndices, zone, cardsToPlay);
  }

  private handlePlayCardInternal(
    player: Player,
    cardIndices: number[],
    zone: 'hand' | 'upCards' | 'downCards',
    cardsToPlay: Card[]
  ): void {
    this.log(
      `Internal play card for player ${player.id} (${player.name}). Zone: ${zone}, Cards: ${JSON.stringify(
        cardsToPlay
      )}`
    );
    if (this.gameState.players[this.gameState.currentPlayerIndex] !== player.id) {
      this.log(
        `Play card rejected: Not player ${player.id}'s turn. Current player: ${this.gameState.players[this.gameState.currentPlayerIndex]}`
      );
      const playerSocket = this.io.sockets.sockets.get(player.socketId);
      if (playerSocket) {
        playerSocket.emit(ERROR_EVENT, 'Not your turn.');
      }
      return;
    }
    if (cardsToPlay.length === 0) {
      this.log('Play card rejected: No cards provided.');
      return;
    }

    const isValid = this.gameState.isValidPlay(cardsToPlay);
    if (!isValid && zone !== 'downCards') {
      this.log(
        `Play card rejected: Invalid play by ${player.id} with cards ${JSON.stringify(
          cardsToPlay
        )} onto pile top: ${JSON.stringify(this.gameState.pile[this.gameState.pile.length - 1])}.`
      );
      if (!player.isComputer) {
        const playerSocket = this.io.sockets.sockets.get(player.socketId);
        if (playerSocket) {
          playerSocket.emit(ERROR_EVENT, 'Invalid play.');
        }
      } else {
        this.log(`Computer player ${player.id} made an invalid play. Forcing pickup.`);
        this.handlePickUpPileInternal(player);
      }
      return;
    }

    if (zone === 'hand') {
      player.setHand(player.hand.filter((_: Card, i: number) => !cardIndices.includes(i)));
    } else if (zone === 'upCards') {
      player.setUpCards(player.upCards.filter((_: Card, i: number) => !cardIndices.includes(i)));
    } else if (zone === 'downCards') {
      player.playDownCard();
    }

    cardsToPlay.forEach((card) => {
      const normalizedValue = normalizeCardValue(card.value) as CardValue;
      const playedCardForPile: Card = { ...card, value: normalizedValue };
      this.gameState.addToPile(playedCardForPile);

      if (!isSpecialCard(normalizedValue) && !this.gameState.isFourOfAKindOnPile()) {
        this.gameState.lastRealCard = playedCardForPile;
      }
    });

    this.io.to(this.roomId).emit(CARD_PLAYED, { playerId: player.id, cards: cardsToPlay, zone });
    this.log(`Emitted CARD_PLAYED for player ${player.id}. Cards: ${JSON.stringify(cardsToPlay)}`);

    const lastPlayedCard = cardsToPlay[0];
    const lastPlayedNormalizedValue = normalizeCardValue(lastPlayedCard.value);

    let pileClearedBySpecial = false;
    if (isTwoCard(lastPlayedNormalizedValue)) {
      this.log(`Special card: 2 played by ${player.id}. Resetting pile.`);
      this.io
        .to(this.roomId)
        .emit(SPECIAL_CARD_EFFECT, { type: 'two', value: lastPlayedNormalizedValue });
      this.gameState.clearPile();
      pileClearedBySpecial = true;
    } else if (this.gameState.isFourOfAKindOnPile() || isTenCard(lastPlayedNormalizedValue)) {
      const effectType = isTenCard(lastPlayedNormalizedValue) ? 'ten' : 'four';
      this.log(`Special card: ${effectType} played by ${player.id}. Burning pile.`);
      this.io.to(this.roomId).emit(SPECIAL_CARD_EFFECT, {
        type: effectType,
        value: lastPlayedNormalizedValue,
      });
      this.gameState.clearPile();
      pileClearedBySpecial = true;
      if (this.gameState.deck && this.gameState.deck.length > 0) {
        const nextCardFromDeck = this.gameState.deck.pop();
        if (nextCardFromDeck) {
          this.gameState.addToPile(nextCardFromDeck);
          if (!isSpecialCard(normalizeCardValue(nextCardFromDeck.value))) {
            this.gameState.lastRealCard = nextCardFromDeck;
          } else {
            this.gameState.lastRealCard = null;
          }
        }
      }
    } else if (isFiveCard(lastPlayedNormalizedValue)) {
      this.log(`Special card: 5 played by ${player.id}. Copying last real card.`);
      this.io
        .to(this.roomId)
        .emit(SPECIAL_CARD_EFFECT, { type: 'five', value: lastPlayedNormalizedValue });
      if (this.gameState.lastRealCard) {
        this.gameState.addToPile({ ...this.gameState.lastRealCard, copied: true });
      }
    }

    if (player.hasEmptyHand() && player.hasEmptyUp() && player.hasEmptyDown()) {
      this.log(`Player ${player.id} (${player.name}) has played all cards. Game Over!`);
      this.io.to(this.roomId).emit(GAME_OVER, { winnerId: player.id, winnerName: player.name });
      this.gameState.endGameInstance();
      this.pushState();
      return;
    }

    if (zone === 'hand' && this.gameState.deck) {
      while (player.hand.length < 3 && this.gameState.deck.length > 0) {
        const drawnCard = this.gameState.deck.pop();
        if (drawnCard) player.hand.push(drawnCard);
      }
      player.sortHand();
    }

    if (pileClearedBySpecial) {
      this.log(`Pile cleared by special card. Player ${player.id} plays again.`);
      this.pushState();
      this.io.to(this.roomId).emit(NEXT_TURN, player.id);
      if (player.isComputer) {
        this.log(`Computer player ${player.id} plays again. Scheduling their turn.`);
        setTimeout(() => this.playComputerTurn(player), 1200);
      }
    } else {
      this.log('Proceeding to next turn.');
      this.handleNextTurn();
    }
    this.pushState();
  }

  private handlePickUpPile(socket: Socket): void {
    const playerId = this.socketIdToPlayerId.get(socket.id);
    this.log(`Handling pick up pile request from socket ${socket.id} (Player ID: ${playerId})`);
    if (!playerId) {
      this.log(`Pick up pile failed: Player not recognized for socket ${socket.id}`);
      socket.emit(ERROR_EVENT, 'Player not recognized.');
      return;
    }

    const player = this.players.get(playerId);
    if (!player) {
      this.log(`Pick up pile failed: Player data not found for ID ${playerId}`);
      socket.emit(ERROR_EVENT, 'Player data not found.');
      return;
    }

    if (this.gameState.players[this.gameState.currentPlayerIndex] !== playerId) {
      this.log(
        `Pick up pile rejected: Not player ${playerId}'s turn. Current player: ${this.gameState.players[this.gameState.currentPlayerIndex]}`
      );
      socket.emit(ERROR_EVENT, 'Not your turn to pick up.');
      return;
    }

    this.handlePickUpPileInternal(player);
  }

  private handlePickUpPileInternal(player: Player): void {
    this.log(
      `Internal pick up pile for player ${player.id} (${player.name}). Pile size: ${this.gameState.pile.length}`
    );
    if (this.gameState.pile.length === 0) {
      this.log(
        `Player ${player.id} tried to pick up an empty pile. This shouldn't typically happen unless it's a forced pickup after an invalid downcard play on an empty pile.`
      );
    } else {
      player.pickUpPile([...this.gameState.pile]);
      this.gameState.clearPile();
      this.log(
        `Player ${player.id} picked up ${this.gameState.pile.length} cards. New hand size: ${player.hand.length}`
      );
      this.io.to(this.roomId).emit(PILE_PICKED_UP, { playerId: player.id });
    }

    this.handleNextTurn();
    this.pushState();
  }

  private handleNextTurn(): void {
    if (!this.gameState.started) {
      this.log('Attempted to advance turn, but game has not started.');
      return;
    }
    this.gameState.advancePlayer();
    const nextPlayerId = this.gameState.players[this.gameState.currentPlayerIndex];
    const nextPlayer = this.players.get(nextPlayerId);

    this.log(
      `Advancing turn. Current player index: ${this.gameState.currentPlayerIndex}, Next player ID: ${nextPlayerId}`
    );

    if (!nextPlayer) {
      this.log(
        `Error: Next player with ID ${nextPlayerId} not found in 'this.players' map. This should not happen.`
      );
      this.io.to(this.roomId).emit(NEXT_TURN, nextPlayerId);
      return;
    }

    if (nextPlayer.disconnected) {
      this.log(`Next player ${nextPlayerId} (${nextPlayer.name}) is disconnected. Skipping turn.`);
      this.handleNextTurn();
      return;
    }

    this.io.to(this.roomId).emit(NEXT_TURN, nextPlayerId);
    this.log(`Emitted NEXT_TURN for player ${nextPlayerId} (${nextPlayer.name})`);

    if (nextPlayer.isComputer) {
      this.log(`Next player ${nextPlayerId} is a CPU. Scheduling their turn.`);
      setTimeout(() => this.playComputerTurn(nextPlayer), 1200);
    }
  }

  private playComputerTurn(computerPlayer: Player): void {
    if (
      !this.gameState.started ||
      this.gameState.players[this.gameState.currentPlayerIndex] !== computerPlayer.id
    ) {
      this.log(`CPU ${computerPlayer.id} turn skipped: not their turn or game not started.`);
      return;
    }

    const bestPlay =
      this.findBestPlayForComputer(computerPlayer, 'hand') ||
      this.findBestPlayForComputer(computerPlayer, 'upCards');

    if (bestPlay) {
      this.handlePlayCardInternal(computerPlayer, bestPlay.indices, bestPlay.zone, bestPlay.cards);
    } else if (computerPlayer.downCards.length > 0) {
      const downCardToPlay = computerPlayer.downCards[0];
      this.handlePlayCardInternal(computerPlayer, [0], 'downCards', [downCardToPlay]);
    } else {
      this.handlePickUpPileInternal(computerPlayer);
    }
  }

  private findBestPlayForComputer(
    player: Player,
    zone: 'hand' | 'upCards'
  ): { cards: Card[]; indices: number[]; zone: 'hand' | 'upCards' } | null {
    const cardsInZone = zone === 'hand' ? player.hand : player.upCards;
    if (cardsInZone.length === 0) return null;

    for (let i = 0; i < cardsInZone.length; i++) {
      const firstCard = cardsInZone[i];
      const sameValueCards = [firstCard];
      const sameValueIndices = [i];
      for (let j = i + 1; j < cardsInZone.length; j++) {
        if (cardsInZone[j].value === firstCard.value) {
          sameValueCards.push(cardsInZone[j]);
          sameValueIndices.push(j);
        }
      }
      if (this.gameState.isValidPlay(sameValueCards)) {
        return { cards: sameValueCards, indices: sameValueIndices, zone };
      }
    }

    for (let i = 0; i < cardsInZone.length; i++) {
      const card = cardsInZone[i];
      if (this.gameState.isValidPlay([card])) {
        return { cards: [card], indices: [i], zone };
      }
    }
    return null;
  }

  private handleDisconnect(socket: Socket): void {
    const playerId = this.socketIdToPlayerId.get(socket.id);
    if (playerId) {
      const player = this.players.get(playerId);
      if (player) {
        player.disconnected = true;
        this.log(`Player ${playerId} (${player.name}) disconnected (socket ${socket.id}).`);
        this.socketIdToPlayerId.delete(socket.id);

        const activePlayers = Array.from(this.players.values()).filter(
          (p: Player) => !p.disconnected
        );
        if (activePlayers.length === 0 && this.gameState.started) {
          this.gameState.endGameInstance();
        } else if (
          this.gameState.started &&
          playerId === this.gameState.players[this.gameState.currentPlayerIndex]
        ) {
          this.handleNextTurn();
          return;
        }
      }
    }
    this.pushState();
    this.io.to(this.roomId).emit(LOBBY, {
      roomId: this.roomId,
      players: this.getLobbyPlayerList(),
      maxPlayers: this.gameState.maxPlayers,
    });
  }

  private pushState(): void {
    const currentPlayerId =
      this.gameState.started &&
      this.gameState.players.length > 0 &&
      this.gameState.currentPlayerIndex >= 0 &&
      this.gameState.currentPlayerIndex < this.gameState.players.length
        ? this.gameState.players[this.gameState.currentPlayerIndex]
        : undefined;

    const stateForEmit: ClientState = {
      players: Array.from(this.players.values()).map((player: Player): ClientStatePlayer => {
        const isSelf =
          player.socketId && this.io.sockets.sockets.get(player.socketId) !== undefined;
        return {
          id: player.id,
          name: player.name,
          hand: isSelf || player.isComputer ? player.hand : undefined,
          handCount: player.hand.length,
          upCards: player.upCards,
          upCount: player.upCards.length,
          downCards: isSelf
            ? player.downCards
            : player.downCards.map(() => ({ value: '?', suit: '?', back: true }) as Card),
          downCount: player.downCards.length,
          disconnected: player.disconnected,
        };
      }),
      pile: this.gameState.pile,
      discardCount: this.gameState.discard.length,
      deckCount: this.gameState.deck?.length || 0,
      currentPlayerId: currentPlayerId,
      started: this.gameState.started,
      lastRealCard: this.gameState.lastRealCard,
    };

    this.players.forEach((playerInstance) => {
      if (playerInstance.socketId && !playerInstance.disconnected) {
        const targetSocket = this.io.sockets.sockets.get(playerInstance.socketId);
        if (targetSocket) {
          const personalizedState: ClientState = {
            ...stateForEmit,
            players: stateForEmit.players.map((p) => ({
              ...p,
              hand: p.id === playerInstance.id ? p.hand : undefined,
              downCards:
                p.id === playerInstance.id
                  ? p.downCards
                  : p.downCards?.map(() => ({ value: '?', suit: '?', back: true }) as Card),
            })),
          };
          targetSocket.emit(STATE_UPDATE, personalizedState);
        }
      }
    });
    if (this.players.size === 0 && !this.gameState.started) {
      this.io.to(this.roomId).emit(STATE_UPDATE, stateForEmit);
    }
  }
}
