Join Button Export

Files included:
- join-button.html    — standalone HTML that demonstrates the button markup
- button.css          — visual CSS for the pill button (use in Figma as spec)
- button.js           — minimal JS for label updates and click wiring

How to use for Figma:
1. Open `join-button.html` in a browser to preview the visual.
2. In Figma, create a component with these layers (back to front):
   - `outer-gold-ring` (stroke ring)
   - `pulsing-glow` (soft radial glow)
   - `deep-shadow` (inset dark layer)
   - `pill-content` group containing two text layers:
     - `text-shadow` (lower, blurred/offset)
     - `text-main` (upper, crisp)
3. Use the CSS values in `button.css` for colors, radii, padding, and shadows.
4. Provide the JS behavior notes to engineers: use `setPlayButtonLabel(label)` to update both text layers when the label changes.

Color and spacing quick reference:
- Text main: #2b2b2b
- Gold gradient: #fff9e6 → #ffd97a
- Gold ring: #d4ad54
- Outer shadow: rgba(0,0,0,0.45)
- Inset shadow: rgba(0,0,0,0.35)
- Glow: rgba(255,210,120,0.35)
- Pill radius: 999px
- Desktop padding: 14px vertical, 36px horizontal
- Desktop font-size: 20px (bold)

If you want, I can produce a Figma layer tree JSON or a zipped download including an SVG export. The zip is available at `exports/join-button-export.zip` if created.